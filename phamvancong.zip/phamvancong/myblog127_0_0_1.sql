-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2017 at 06:58 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myblog`
--
CREATE DATABASE IF NOT EXISTS `myblog` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `myblog`;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `comment_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `user_id`, `post_id`, `comment_text`, `created_at`, `updated_at`) VALUES
(1, 9, 2, 'sfsdfds', '2017-11-26 08:29:08', '2017-11-26 08:29:08'),
(2, 9, 2, 'sgddjfhkghk', '2017-11-26 08:33:37', '2017-11-26 08:33:37'),
(3, 9, 2, 'zczczcz', '2017-11-26 08:38:22', '2017-11-26 08:38:22'),
(4, 9, 2, 'fsdfsdfs', '2017-11-26 08:40:17', '2017-11-26 08:40:17'),
(5, 9, 2, 'day la noi dung test thu nhe', '2017-11-26 08:40:25', '2017-11-26 08:40:25'),
(6, 9, 2, 'day la noi dung tst 33', '2017-11-26 08:40:54', '2017-11-26 08:40:54'),
(7, 9, 2, 'ssfsfsaf afa fa', '2017-11-26 08:41:09', '2017-11-26 08:41:09'),
(8, 9, 2, 'ssfsfsaf afafafa fa', '2017-11-26 08:41:12', '2017-11-26 08:41:12'),
(9, 1, 16, 'test thu nnhe', '2017-11-26 10:02:23', '2017-11-26 10:02:23'),
(10, 1, 13, 'test lai lan nua', '2017-11-26 10:03:47', '2017-11-26 10:03:47'),
(11, 1, 10, 'test noi dung comment', '2017-11-26 10:09:27', '2017-11-26 10:09:27'),
(12, 1, 10, 'test lai nhe', '2017-11-26 10:10:27', '2017-11-26 10:10:27'),
(13, 1, 10, 'test lai lan nua xem', '2017-11-26 10:11:07', '2017-11-26 10:11:07');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `like` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `user_id`, `post_id`, `like`, `created_at`, `updated_at`) VALUES
(2, 9, 2, 0, '2017-11-26 09:00:35', '2017-11-26 09:00:35'),
(3, 1, 16, 1, '2017-11-26 09:56:15', '2017-11-26 09:56:15'),
(4, 1, 10, 0, '2017-11-26 10:11:23', '2017-11-26 10:11:23'),
(6, 10, 15, 1, '2017-11-26 10:51:37', '2017-11-26 10:51:37'),
(7, 3, 15, 1, '2017-11-26 10:56:37', '2017-11-26 10:56:37');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2017_11_26_130243_create_permission_tables', 1),
(4, '2017_11_26_132010_create_posts_table', 2),
(5, '2017_11_26_144812_add_birthday_to_users', 3),
(6, '2017_11_26_151247_create_comments_table', 4),
(7, '2017_11_26_154551_create_likes_table', 5);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `model_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `model_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_id`, `model_type`) VALUES
(1, 1, 'App\\User'),
(2, 2, 'App\\User'),
(3, 3, 'App\\User'),
(4, 4, 'App\\User'),
(4, 5, 'App\\User'),
(4, 8, 'App\\User'),
(4, 9, 'App\\User'),
(4, 10, 'App\\User');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'Create Post', 'web', '2017-11-26 06:55:05', '2017-11-26 06:55:05'),
(2, 'Edit Post', 'web', '2017-11-26 06:55:16', '2017-11-26 06:55:16'),
(3, 'Delete Post', 'web', '2017-11-26 06:55:26', '2017-11-26 06:55:26'),
(4, 'Administer roles & permissions', 'web', '2017-11-26 06:55:36', '2017-11-26 06:55:36'),
(5, 'View Post', 'web', '2017-11-26 07:01:57', '2017-11-26 07:02:54');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `created_at`, `updated_at`) VALUES
(1, 'Test for new Post 1', 'This is content of post 1', '2017-11-26 07:11:22', '2017-11-26 07:11:22'),
(2, 'sdasd', 'adadasd', '2017-11-26 07:26:09', '2017-11-26 07:26:09'),
(3, 'Play stations: Railway stops worth lingering at', 'The golden age of rail travel appears to be well and truly over, and stations lack the glamour formerly associated with letting the train take the strain. Often unmanned and usually unloved, they are places to hurry through.\r\nCommuters on the daily grind tend to be grimly determined when leaving a train. Heads down, elbows out, it\'s a fight to get to the exit. The only reason to pause is to grab a cardboard cup of something caffeinated before stalking out into the ice-spiked drizzle of a dark winter\'s morning.\r\nBut what if your station wasn\'t full of faceless coffee chains and people pushing? What if there was a station garden filled with fragrant shrubs, or an art gallery, or a top-notch local restaurant?\r\nHere are some everyday railway stations with added extras you may wish to linger at - or even arrive early for.', '2017-11-26 09:04:33', '2017-11-26 09:04:33'),
(4, 'The seizures have got more frequent and more violent', '\"It\'s really frightening. You think \'is she going to be ok or do I have to phone for an ambulance again?\'.\r\n\"What\'s she going to be like when she comes round? It\'s a daily struggle\".\r\nKiley Lay\'s daughter Katie suffers from epilepsy. The 17-year-old from Essex has had the condition since she was two-years-old. but recently her illness has taken a turn for the worse.\r\n\"The seizures have got more frequent and more violent. She\'ll try and scratch herself and pull her hair. She\'s had 124 seizures since April.\"\r\n\'Not good enough\'\r\nKatie was having daily seizures in the summer, so her family turned to their GP for help.\r\nThey were told their daughter could be referred to a neurologist - but there was a waiting list.\r\nThe earliest she could see a neurologist would be February next year.\r\nKiley says: \"We need the appointment brought forward because Katie\'s seizures were getting more prolonged\".\r\nFollowing a recent visit to A&E, a request for an urgent referral was made for Katie and she is due to see a consultant who specialises in epilepsy in early December.\r\nBut she will still have to wait until February to see a neurologist.\r\nKatie said: \"It made me angry because I can\'t really wait that long. I would love to be a free spirit and live my life.\"\r\nA spokesperson for Basildon and Thurrock University Hospitals NHS Foundation Trust told the programme: \"There is a national shortage of neurology consultants and the trust has been proactively working to recruit specialist doctors.\"\r\nIt added one consultant was due to start in March 2018 and the trust was advertising for another.\r\nKatie LayImage copyrightROB LAY\r\n\'Failing patients\'\r\nEarlier this year, a report published by the Neurological Alliance found that that services to diagnose, treat and provide on-going care are failing patients across the spectrum of neurological disorders.\r\nIt surveyed 7,000 neurology patients in England about their experience of getting access to care and treatment.\r\nIt found that 23% waited more than 12 months to see a neurological specialist after their first visit to a GP.\r\nSuzanne Dobson, chair of the alliance, said: \"The impact is huge. For a few, it will mean that they didn\'t get treatment earlier enough and so bits of their conditions that many have been reversible, manageable, get worse during the period and they can\'t get that back.\"\r\nMeanwhile, a separate report published in March by the Association of British Neurologists (ABN) found that the likelihood of a patient with a neurological problem being seen by a neurologist varies dramatically depending on where they are admitted.\r\nIt found one in five UK hospitals have access to neurologists on three days a week or less.\r\nDiagnosis\r\nAnother area of concern highlighted within the Neurological Alliance\'s research was the length of time it took to patients to get a diagnosis.\r\nIt found that 42% of patients saw a GP five or more times before seeing a neurological specialist.\r\nThe National Institute for Health and Care Excellence (NICE) has recognised this as an issue and in January is due to publish new guidance for the health professionals like GPs to help them to better recognise neurological conditions.\r\nThe draft guidance says \"a lack of support\" to help non-specialists identify when a referral is needed, has led to \"delays in referral for people with treatable or potentially serious neurological conditions\".\r\nTwo years ago a Public Accounts Committee report criticised the wide variations in neurology care in England.\r\nThe committee\'s chair, Meg Hillier, MP said despite their warnings the situation had not improved.\r\n\"Evidence shows from our committee that in 2012 the system wasn\'t fit for purpose, that in 2015 it wasn\'t and from the evidence 5 live Investigates has shown me, and the Neurological Alliance have been reporting, it\'s not got any better. In fact it looks like its going backwards\".\r\nAn NHS England spokesperson said a national advisory group on neurology was formed last year, bringing together patient groups within the Neurological Alliance, NHS England and other organisations.\r\nShe said: \"Its aim is to direct the development of national work to improve outcomes for people living with neurological conditions\".\r\nA Department of Health spokesperson added: \"We spend over £3 billion every year on neurological services and the number of neurologists in the NHS has increased by 37% since 2010.\r\n\"However, local services must also ensure patients with neurological disorders receive timely care and support and have access to specialists when they need it.\"\r\n5 live Investigates is broadcast on Sunday 26th November 2017 at 11am GMT. If you\'ve missed it you can catch up on the iPlayer.', '2017-11-26 09:05:17', '2017-11-26 09:05:17'),
(5, 'The breath-taking alien world of plastic bags under the sea', 'At first glance freediver Janeanne Gilchrist\'s photographs appear to show \"alien\" underwater creatures but closer inspection reveals something far less mythical.\r\nThe images, taken while the Scottish photographer was holding her breath up to 45ft (15m) beneath the surface, include a decomposing plastic bag, a discarded sou\'wester and the tangle of fishermen\'s rope.\r\nJaneanne says her images are a bit like a psychological Rorschach test where what you see depends on your state of mind at the time.\r\nanthropomorphism.jpg\r\nImage caption\r\nA discarded fisherman\'s sou\'wester\r\nThe Edinburgh artist, who has been diving without breathing equipment for 15 years, says her images are \"completely unique\" and cannot be reproduced.\r\nShe says: \"I am trying to capture something that\'s never going to be in the same location, same light, same position, ever again.\"\r\n\"Capturing these moments while freediving in challenging conditions in the waters around Scotland isn\'t easy.\r\n\"The current is playing with them and with me, the entire time.\"\r\nsemantic_memory.jpg\r\nImage caption\r\nA fisherman\'s rope captured for Semantic Memory\r\nFreediving is taking one breath and holding it underneath the water. There is no oxygen tank or scuba diving equipment, although a good wetsuit is a necessity in the waters of the east coast of Scotland.\r\nJaneanne says: \"We don\'t do it naked in this country, I\'m afraid, we have to have a wetsuit on so we can keep warm.\"\r\nShe says she has trained to be a freediver but taking photos while holding your breath adds an extra layer of complexity.\r\nstructuralism.jpg\r\nImage caption\r\nA tangle of fishing net is the subject of Janeanne\'s photograph Structuralism\r\nJaneanne says: \"I have to get to the place, to compose the shot, to manoeuvre myself around it, to get what I need and come back up, all the time focussing on how much air I have got in my body.\"\r\nShe dives with her partner at sites all around Scotland and says St Abbs head, off the Berwickshire coast, is a favourite spot.\r\nmulticellular.jpg\r\nImage caption\r\nSpawning seaweed is the subject of the image Multicellular\r\nThe couple dive for more than four hours at a time and have made numerous trips in order to capture the photos being displayed in the new exhibition at the Fergusson Gallery in Perth.\r\nJaneanne says the temperature, tide, time of year, weather, and the unpredictable moods of the sea combine to create the temporary shapes and lighting that make her photographs.\r\nShe says: \"I am trying to let people experience what my mind\'s eye sees when I am under the water.\r\n\"Some of the works have been created from things that are in the water through pollution.\r\n\"These are the ones that are kicking a bigger question back about why they are there and how can we make sure they are not there?\"\r\natomic.jpg\r\nImage caption\r\nThe alien glow of a jellyfish captured in an image called Atomic\r\nThe irony is that she makes the debris that should not be in the sea look beautiful and ethereal.\r\nJaneanne says: \"That\'s the irony I am playing with here.\r\n\"People have become quite numb to photos of piles of waste. These images are created to last longer and I want people to have these discussions.\"', '2017-11-26 09:06:05', '2017-11-26 09:06:05'),
(6, 'The female war medic who refused to \'go home and sit still\'', 'When Elsie Inglis asked the War Office if female doctors and surgeons could serve in front-line hospitals in World War One she was told \'my good lady, go home and sit still\'.\r\nElsie, a pioneering Edinburgh doctor who had already become well-known as a champion of women\'s health, did the opposite.\r\nInstead, she formed the Scottish Women\'s Hospitals - all female units that provided support for Britain\'s allies, the French, the Belgians and especially the Serbs.\r\nElsie was 50 when war broke out and had already made a mark in Edinburgh by working with women and babies in the poorest parts of the city.\r\nMedals\r\nImage caption\r\nWar medals belonging to Dr Inglis have been displayed in Edinburgh\r\nShe was also a prominent campaigner for votes for women and it was through the suffrage movement that she began to raise money to send out female doctors, nurses, orderlies and drivers to the front line.\r\nElsie raised the equivalent of £53m in today\'s money and over the course of the war set up 14 hospitals, staffed by 1,500 women who volunteered from all over Scotland, and later from New Zealand, Australia and Canada.\r\nThese woman were often unmarried and wanted to prove their independence and capability on the front line.\r\nThey worked in dire conditions to treat hundreds of thousands of injured men during the bloody conflict.\r\n\'Horrendous conditions\'\r\nWithin months of the outbreak of war she had started a hospital in the north of France and field hospitals were set up close to battlefields across Europe including, in particular, Serbia.\r\nWriter and researcher Louise Miller said the Balkan country was devastated by the war when, as well as being invaded, it was gripped by a typhus epidemic. In total, it lost about 16% of its population.\r\n\"Serbs needed any competent help they could get. They didn\'t care about the form it took: male, female, young, old - anybody,\" she said.\r\nThe first Scottish Women\'s Hospital field unit was formed in December 1914 in a town called Kragujevac in Serbia.\r\nAccording to historian Alan Cumming, who has done much to resurrect Elsie\'s memory, the conditions were \"horrendous\".\r\nletterImage copyrightANDREW COWAN\r\nImage caption\r\nDr Elsie Inglis was told that the need for help in Serbia was \"very pressing\"\r\nHe says the typhus epidemic meant Serbia \"was on its knees\".\r\nFour of the staff from the Scottish Women\'s Hospitals had already died and Elsie herself went out to Serbia to set up four typhus hospitals.\r\nBy the autumn of 1915, Serbia was invaded by the Austrian army and the \"great retreat\" began.\r\nElsie refused to abandon her hospital and she and about 80 women became \"effectively prisoners of war\", Mr Cumming says.\r\nHe says that after a couple of months \"the Germans had had enough of them and sent them home\".\r\nSerbian stampsImage copyrightBRITISH EMBASSY TO SERBIA\r\nImage caption\r\nIn 2015 Inglis and five other female volunteers were honoured by appearing on commemorative Serbian stamps\r\nAbout 200,000 men, women and children died on the retreat over the mountains of Albania and Montenegro in the depths of winter.\r\nElsie campaigned for help for Serbia and was upset at how they were treated by the Allies.\r\n\"In the latter part of 1916 she headed off again to support her beloved Serbs who had been called to the Russian front,\" Mr Cumming says.\r\njournalImage copyrightANDREW COWAN\r\nImage caption\r\nBooklets compiled by British suffrage groups raised money for Scottish Women\'s Hospitals\r\nBy this time she knew she had cancer but set up two field hospitals, staffed by about 80 women.\r\nThe British government demanded she come home but Elsie refused until the Serbian soldiers were guaranteed safe passage.\r\nThe boat brought them back to Newcastle and Elsie, who was crippled with illness, could hardly walk as she greeted Serbian soldiers on deck.\r\nShe was so frail she had to be carried off to a nearby hotel where she died on 26 November 1917.\r\nMr Cumming, an amateur historian who discovered Elsie\'s story while on a football trip to Serbia a decade ago, says her massive achievements have been \"neglected\".\r\nWhen he first found her headstone in Dean Cemetery in Edinburgh it was covered in green algae, he says.\r\nElsie Inglis\r\nImage caption\r\nElsie Inglis established Scottish Women\'s Hospitals in Edinburgh in 1914\r\nA private ceremony will be held at her grave on Sunday to mark the centenary of her death.\r\nAs a mark of her growing reputation, a commemoration will also take place at St Giles Cathedral on Wednesday.\r\nMr Cumming says the contribution Elsie made to Serbia\'s war effort was \"enormous\".\r\nHe says the country still celebrates her as \"the Serbian mother from Scotland\".\r\n\"In Serbia they have street names, exhibitions, museums and even some new facilities named after, not just Elsie Inglis but a number of the other women who served in the Scottish Women\'s Hospitals,\" he says.\r\n\"They absolutely love her. \"\r\nFor Mr Cumming, there are at least three reasons why Elsie was a remarkable woman.\r\nFirstly, there was her work among the poor - and particularly maternity services for women who could not afford care. Then there was her fearless campaigning for votes for women. Finally, organising the Scottish women who went to the front line in WW1.\r\n\"If you are a young women in Scotland today and you are looking for a role model, someone to inspire you, then I suggest you look at the life of Elsie Inglis,\" he says.', '2017-11-26 09:06:34', '2017-11-26 09:06:34'),
(7, 'The early Christmas gift everyone\'s buying', 'Advent calendars used to be a cheap way to count down to Christmas with a seasonal picture or chocolate treat, but behind the doors you can now find everything from expensive whisky to fancy face cream. Are they a rip-off that represents the ever-growing commercialism of Christmas, or just a harmless bit of festive fun?\r\n\"Christmas isn\'t like it used to be,\" is a familiar refrain. Yet even putting the rose-tinted spectacles aside, one element of the festive period - advent calendars - really have come a long way.\r\nThere has long been a tradition in some Christian denominations to mark off the days of Advent, from lighting candles to the calendar\'s austere origins in 19th Century Germany when 24 chalk lines were rubbed off doors.\r\nBut counting down to a festival marking the birth of Jesus has changed, from finding cheap chocolate behind the door of a pretty picture - a style popularised in the 1990s - to an extravagant present-filled bonanza boasting everything from pork scratchings to posh toiletries.\r\ntraditional card advent calendarImage copyrightJOHN LEWIS\r\nImage caption\r\nTraditional card advent calendars are still popular, says John Lewis\r\nThese bumper versions vary wildly in price, ranging from £10,000 for a rare whisky version, to a rather more modest cheese offering for £8 from Asda.\r\nBut despite the sometimes eye-watering cost, some do represent value for money, according to MoneySavingExpert\'s Gary Caffell.\r\n\"If you want to give yourself a small daily treat of your favourite tipple, cheese or crisp, Advent calendars such as these are meant to be a bit of festive fun. So if that\'s why you\'re buying it and you\'re happy with the overall price, you may not be too fussed about the value you\'re getting behind each window.\"\r\n\"Self-rewarding\" is how consumer psychologist Kate Nightingale, founder of consultancy Style Psychology puts it.\r\nWhen you are rushing around trying to please everyone else, treating yourself to an early present is one way to cheer yourself up, she says.\r\nChloe Haskoll, 34, says that is exactly why she bought a beauty advent calendar for herself this year.\r\n\"I\'m not keen on chocolate and like the idea of a daily pick-me up. They\'re not cheap but I find December exhausting so it\'s a well deserved treat, I reckon,\" she says.\r\nChloe HaskollImage copyrightCHLOE HASKOLL\r\nImage caption\r\nChloe Haskoll says her beauty calendar will be a \"pick-me up\" in a tough month\r\nMr Caffell says beauty calendars tend to provide the best savings as they can be a cheaper way to buy a lot of products from one of the bigger brands, and any products you don\'t want can be given as stocking-fillers.\r\n\"Boots No7, M&S and Body Shop all have popular calendars which are worth looking out for, as you get products worth a lot more than the price of the Advent calendar itself.\"\r\nNatalie Oakley, who is behind beauty blog Lady Like Momma, has been known to stay up for the midnight launch of such calendars and tracks the launch dates in magazines and online.\r\n\"I choose a calendar based on two things,\" says the writer, from Sedgley in the West Midlands. \"I either go for a brand I know and love already, or brands that I am keen to try out.\r\n\"And the second thing is the style [and] packaging. I think when you are spending quite a lot on a calendar you want it to look good in your home and I personally want to be able to use it again the following year and add my own things to the drawers.\"\r\nNatalie OakleyImage copyrightLADY LIKE MOMMA\r\nImage caption\r\nNatalie Oakley reuses her beauty calendars by adding her own things to the drawers\r\nFrom top left clockwise: Cadbury\'s advent calendars from 1971, 1993 and 1972Image copyrightCADBURY\r\nImage caption\r\nCadbury launched its first Advent calendar in 1971, but only started producing them every Christmas from 1993\r\nLuxury calendars are a very recent phenomenon - department store Liberty\'s coveted beauty calendar, which sold out online in 39 hours this year, only launched in 2014.\r\nEven chocolate calendars only really became commonplace in the 1990s, says Alex Hutchinson, archivist and historian for Nestle.\r\n\"It wasn\'t until after World War Two and after rationing ended that chocolate became a more affordable purchase.\r\n\"Chocolate was so expensive that manufacturers couldn\'t afford to put it in an Advent calendar. By the 1960s, people got back into the habit of treating it as a grocery product but [the idea of chocolate being linked to Advent] would still have been a bit sacrilegious.\"\r\nPresentational grey line\r\nYou might also like:\r\nWill the four gift rule take off?\r\nWhen should you do your Christmas shopping?\r\nCan you cook Christmas dinner for £1?\r\nPresentational grey line\r\nCadbury\'s says the company launched its first Advent calendar in 1971, with production the following year and again between 1978 and 1980.\r\nIt wasn\'t until 1993 the firm began to produce them continuously, when it became more routinely adopted as a Christmas tradition.\r\nBut trying to marry the commercial desire to sell more during what is, after all, a religious festival, requires some sensitivity.\r\nWhen bakery chain Greggs promoted its advent calendar by swapping Jesus for a sausage roll in a nativity scene, some said it had gone too far.\r\nYouTube star Zoella also came a cropper when parents complained that her £50 12-window calendar was \"overpriced tat\", prompting Boots to halve the price to £25.\r\nGreggs sausage roll in nativity sceneImage copyrightGREGGS\r\nImage caption\r\nGreggs was forced to apologise for swapping Jesus for a sausage roll in its advent calendar promotion\r\nThere are other less obvious pitfalls for retailers.\r\nThose fiddly boxes and unusual shapes mean they can be difficult and expensive to make, something pork scratchings firm Snaffling Pig found to its cost when it launched its first calendar last year.\r\nThe firm\'s founder Andy Allen says a combination of the A3 size, which took up almost all their warehouse space; and the need to produce the calendar in a short space of time to keep the product fresh, \"almost broke them\".\r\nThe result was that they had less than a month to make and then post out 11,000 calendars before 1 December.\r\n\"It piled on a lot of pressure,\" he says.\r\nThis year, they are making about 45,000 calendars and have outsourced the fiddly filling and calendar construction to a team.\r\n\"It is a bit more controlled,\" he says.\r\nSnaffling Pig advent calendarImage copyrightDANIEL JARVIS\r\nImage caption\r\nSnaffling Pig struggled to make all its Advent calendars on time last year\r\nFor larger firms like John Lewis, Advent is akin to a military operation.\r\nHead of Christmas products Dan Cooper has already picked his first set of calendars for next Christmas and across all styles, sales are up 48% so far this year.\r\nThe chain launched its own £149 beauty product calendar for the first time this year, and the 3,000 it made have already sold out.\r\nMr Cooper believes the growing popularity of more luxurious calendars is partly down to the ever earlier spread of \"Christmas hysteria\".\r\nBut he says the real shift is that calendars have become \"a family thing\". Advent, it seems, is no longer just for kids.\r\nLego City advent calendarImage copyrightJOHN LEWIS\r\nImage caption\r\nJohn Lewis says the Lego advent calendars are its strongest sellers\r\nAngus Thirlwell is the chief executive and founder of chocolate chain Hotel Chocolat, which has been selling a \"posh calendar\" pitched squarely at adults for nearly a decade now.\r\nHe says people are generally buying calendars in addition to their usual Christmas gifts - not instead of them - and Advent has now become \"a season in its own right\".\r\n\"That\'s why we like it,\" he says.\r\nBut isn\'t festive commercialism getting a bit out of hand?\r\n\"It\'s difficult to take the hedonism out of Christmas, the genie has already escaped the bottle,\" says Mr Thirlwell.\r\nLiberty advent calendar queueImage copyrightEAMONN M. MCCORMACK\r\nImage caption\r\nMen outnumbered women by two to one in the queue to buy Liberty\'s calendar this year\r\nRetailers, of course, say these calendars are a good deal - to the point of printing it on your receipt.\r\nIn a clever marketing ploy. Marks & Spencer\'s beauty calendar (which is £35 if you spend an additional £35 on non-food products), flashes up at the till at £250, which is what the company says it\'s worth before the price is reduced.\r\nBut customer reviews show they believe the chance to try more expensive products than they could normally afford makes them worth it.\r\nAnd glowing skin isn\'t necessarily the only bonus. Some calendars\' popularity mean they can be lucrative.\r\nLiberty\'s £175 beauty calendars are now listed on auction site eBay at double the original price, for example.\r\nThe idea that shops are deliberately under-stocking their calendars to create a fake rush is a \"myth\" according to Mr Cooper, who adds that changing trends mean \"things sometimes sell better than expected\".\r\nBut however big your advent calendar is, and whatever you paid for it, there\'s still one big challenge left - stopping yourself from opening all those tempting little windows at once.', '2017-11-26 09:07:03', '2017-11-26 09:07:03'),
(8, 'Brexit: Ireland \'to play tough\' over talks - commissioner', 'The Irish Republic\'s EU commissioner has said Dublin will \"play tough to the end\" over its threat to veto Brexit talks moving on to discuss trade.\r\nThe European Union has said \"sufficient progress\" has to be made on the Irish border before negotiations on the UK and EU\'s future relationship can begin.\r\nPhil Hogan told the Observer staying in the customs union would avoid the need for a hard border on the island.\r\nThe DUP said Northern Ireland and the rest of the UK must not be different.\r\nArlene Foster, the leader of the Democratic Unionist Party, which is in a confidence-and-supply arrangement with the Conservative government, said she would not support \"any suggestion that Northern Ireland, unlike the rest of the UK, will have to mirror European regulations\".\r\nDUP hits out at Irish government\'s Brexit stance\r\nBrexit: All you need to know\r\nSix things to watch if Brexit puzzles you\r\nDowning Street has said the whole of the UK will leave both the customs union and the single market when it leaves the EU in 2019.\r\nLabour said nothing should be done that endangers the Good Friday Agreement in Northern Ireland, while the Liberal Democrats said Tory divisions over Brexit were \"stoking tensions\".\r\n\'Blind faith\'\r\nThe EU has given Prime Minister Theresa May until 4 December to come up with further proposals on issues including the border, the Brexit divorce bill and citizens\' rights, if European leaders are to agree to moving on to trade talks.\r\nBut Mr Hogan, the EU\'s agriculture commissioner, accused some in the British government of having what he called a \"blind faith\" about securing a comprehensive free trade deal after Brexit.\r\nHe said it was a \"very simple fact\" that \"if the UK or Northern Ireland remained in the EU customs union, or better still the single market, there would be no border issue\".\r\nIn these circumstances regulations either side of the border would remain the same, and so a near invisible border would be possible.\r\nTaoiseach (Irish Prime Minister) Leo VaradkarImage copyrightGETTY IMAGES\r\nImage caption\r\nTaoiseach Leo Varadkar has asked for assurances of no hard border\r\nThe Irish government has always insisted there must not be a hard border between the Republic and Northern Ireland, with Taoiseach Leo Varadkar saying he must have written assurance from the UK before Brexit talks can move on.\r\nIrish Foreign Minister Simon Coveney has also said the UK\'s desire for no hard-border on the island of Ireland was \"aspirational\".\r\nReport suggests \'low friction\' Brexit border solution\r\nUK approach to Brexit \'chaotic\' - leaked Irish report\r\nThere could be no movement to phase two \"on the basis of aspiration\", he said.\r\nBut in her speech in Florence, this September, Mrs May restated that both the UK and EU will not accept any physical infrastructure at the border.\r\n\'Desperately worried\'\r\nMeanwhile, International Trade Secretary Liam Fox told Sky News: \"We don\'t want there to be a hard border but the United Kingdom is going to be leaving the single market and customs union.\"\r\nHe said progress towards a deal must be quicker and accused EU negotiators of making the so-called \"divorce bill\" a sticking point, adding: \"We can\'t get a final answer to the Irish question until we get an idea of the end state.\"\r\nShadow international trade secretary Barry Gardiner told the BBC\'s Andrew Marr Show that the Irish government was \"desperately worried\" about the possibility of a hard border.\r\nHe said Labour had not ruled out advocating membership of the single market or, if necessary, some form of customs union.\r\nBut he declined to commit to a preferred solution, arguing that Labour was not in government and therefore not involved in the Brexit talks.\r\n\"I\'d be very happy if Theresa May wanted to move over and call that election and let us do that, but until we\'re round that table it\'s not sensible to say what you can get out of the negotiations,\" he said.\r\nLiberal Democrat Brexit spokesman Tom Brake said: \"Government divisions over what Brexit means are stoking tensions. The government and its Brextremists must swallow their pride and do the right thing for Ireland and the UK.\r\n\"Leaving the EU does not have to mean leaving the single market and customs union.\"\r\nSuggestions for alternate arrangements have included a new partnership that would \"align\" customs approaches between the UK and the EU, resulting in \"no customs border at all between the UK and Ireland\".', '2017-11-26 09:07:40', '2017-11-26 09:07:40'),
(9, 'Armed police chief and deputy suspended', 'The head of armed policing and his deputy are understood to be among those suspended by Police Scotland amid allegations of criminal conduct and gross misconduct.\r\nAssistant Chief Constable Bernard Higgins was suspended on Friday by the Scottish Police Authority.\r\nIt is understood Supt Kirk Kinnell and his deputy, Chief Inspector Bob Glass, are among the other officers under investigation.\r\nOne other officer has been suspended.\r\nA further two have been placed on restricted duties.\r\nChief Inspector Glass was head of Strathclyde Police\'s armed response unit at the time of the 2007 terror attack on Glasgow Airport.\r\nJustice Secretary Michael Matheson confirmed to BBC Scotland that two officers named in a Sunday Mail story, Supt Kinnell and Chief Inspector Glass, were under investigation.\r\n\'Firearms training\'\r\nHe told the Sunday Politics Scotland programme: \"I think at this stage it wouldn\'t be appropriate for me to start mentioning names of those particular officers.\r\n\"But the two which I know have been suggested are individuals who were involved in the investigation.\r\n\"As far as I am aware, they are two of those who are part of the complaint that has been received by the Pirc (the Police Investigations and Review Commissioner) that is being investigated by the Crown Office.\r\n\"The individuals involved in this are related to those involved in the firearms unit at Police Scotland in the training facility that we have at Jackton.\"\r\nBernard Higgins\r\nImage caption\r\nACC Bernard Higgins was suspended on Friday afternoon\r\nHe added: \"I don\'t want to get drawn into it (what the allegations relate to) too much because it is a live investigation being directed by the Crown. But, as far as I\'m aware, it relates to issues of misconduct and gross misconduct.\r\n\"The exact detail of that is for the Crown to determine because it is now a live, potentially criminal, investigation.\r\n\"Like any investigation that could be criminal in nature, it is important that we recognise there is due process to be gone through here.\r\n\"And also for the individuals who have the complaints lodged against them, (it is important) that we allow that process to take its course.\"\r\n\'Counter-corruption unit\'\r\nThe Police Investigations and Review Commissioner (Pirc) is also looking into allegations of misconduct against Chief Constable Phil Gormley, who is currently on \"special leave\".\r\nThat investigation is unrelated to inquiries into allegations that officers in the former counter-corruption unit abused their position when attempting to find the source of a journalist\'s information.\r\nBoth Mr Gormley and Mr Higgins have denied wrongdoing.\r\nACrown Office spokesman said: \"We can confirm that the Crown Office and Procurator Fiscal Service (COPFS) has instructed the Police Investigations & Review Commissioner (PIRC) to undertake an investigation into allegations of a criminal nature against officers serving with the Police Service of Scotland.\r\n\"A report will be submitted to COPFS following the investigation by PIRC.\"\r\nSusan Deacon\r\nImage caption\r\nWillie Rennie said the new SPA chief Susan Deacon should appear before MSPs\r\nThe Scottish Police Authority confirmed the suspensions on Friday after \"a number of criminal and misconduct allegations were brought to the Authority\'s attention by the Police Investigations and Review Commissioner (PIRC)\".\r\nA spokesman for the SPA said on Sunday: \"The Authority will not provide any further detail in relation to the allegations.\"\r\nThe Scottish Liberal Democrat leader, Willie Rennie said Michael Matheson needed to address the issue at Holyrood.\r\nHe said: \"The justice secretary needs to make a statement to Parliament to set out how leadership of Police Scotland will be secured while the months of investigation take place into senior officers.\r\n\"The public and all ranks of the police service deserve to hear the means by which effective force management will be provided.\"\r\nMr Rennie said the SPA\'s new chair Susan Deacon should also appear before MSPs.', '2017-11-26 09:08:03', '2017-11-26 09:08:03'),
(10, 'NHS watchdog staff \'told not to criticise\' Welsh Government', 'Staff working for Wales\' community health councils have been told by senior colleagues not to criticise or embarrass the Welsh Government over plans to scrap the independent watchdogs, BBC Wales has learned.\r\nMinisters have consulted on replacing CHCs with one organisation.\r\nOne CHC member told BBC\'s Sunday Politics Wales their council\'s response to the consultation was \"toned down\".\r\nMutale Merrill, chairwoman of the CHC board, said the claims were untrue.\r\nCHCs are independent bodies representing the interests of patients.\r\nThere are seven in Wales - one for each of the health boards which run NHS services. They were scrapped in England in 2003 and in Scotland in 2005.\r\nJust how has our Welsh health service changed in 20 years?\r\nWelsh NHS watchdogs set to be scrapped\r\nHealth board complaints on the rise\r\nThe Welsh Government has said there were questions over whether the CHC model, which has been in place since 1974, is \"flexible enough\" to respond to health and social care services which work increasingly across organisational boundaries.\r\nIt also said CHCs \"lack visibility\" and their membership was \"not at all representative of local communities\".\r\nInstead, the Welsh Government proposes to create a \"new independent arrangement to replace CHCs... working across health and social care\".\r\nConsultation on the plans ended in September.\r\nBBC Wales has learned staff working for CHCs across Wales have been asked by senior colleagues not to overly-criticise or embarrass the government over the proposals.\r\nOne CHC member, speaking anonymously, said that was why their CHC\'s response to the consultation was \"toned down\".\r\n\r\n\r\nMedia captionCHC board \"not overly concerned\" by consultation\r\nMutale Merrill, chairwoman of the Board of Community Health Councils, which represents and sets standards for the organisations, said: \"It\'s not true\".\r\n\"I know my staff and members have worked really hard during the consultation period and I just think it\'s unfair and irresponsible for this rumour to be circulating.\"\r\nPlaid Cymru AM Llyr Gruffydd said: \"To suggest that people should not embarrass the government I think is a total dereliction of duty.\"\r\nMr Gruffydd also criticised the government\'s plans.\r\n\"The CHC in north Wales is genuinely seen as the guardian of patients\' interests,\" he said.\r\n\"To lose that kind of integrity in terms of the voice of the patient I think would be an unmitigated disaster and to move from an organisation that\'s deeply rooted in the community to what could potentially be a very remote national body, no doubt based in Cardiff, would be a terrible, terrible loss.\"\r\nThe Welsh Government has previously said its aim \"is to strengthen citizen engagement across health and social care\".\r\nA spokesman said: \"We firmly believe people should be free to comment openly and honestly on any consultation process, especially one that potentially affects the future of their organisation.\"\r\nHe added it was considering the \"large number\" of responses received to the consultation', '2017-11-26 09:08:26', '2017-11-26 09:08:26'),
(11, 'Home Office review over harassment at abortion clinics', 'New laws could be introduced to protect women from harassment outside abortion clinics, the Home Office has said.\r\nAn assessment of protests held outside clinics has been ordered by the home secretary, following concerns about the tactics used by some protesters.\r\nAmber Rudd said it was \"unacceptable\" that anyone should feel intimidated for accessing healthcare advice and treatment.\r\nLabour MP Rupa Huq, who has campaigned for a law change, welcomed the review.\r\nIn her Ealing Central and Acton constituency, the council backed a proposal in October that would ban protesters from gathering outside an abortion clinic.\r\nThe demonstrators, who hold daily vigils outside the clinic, deny harassing women.\r\nEaling abortion clinic protest ban approved\r\nBuffer zone plan for Portsmouth abortion clinic\r\nAbortion stories: From a \'sense of relief\' to a \'broken heart\'\r\nThe Home Office review will hear from police forces, healthcare providers and local authorities to understand the scale and nature of the protests.\r\nIt will then consider what further action the government could take to protect those using or working in abortion clinics.\r\nThis could include bolstering existing, or creating new, police and civil powers, the Home Office said.\r\n\'Cautious optimism\'\r\nMs Rudd said: \"While everyone has a right to peaceful protest, it is completely unacceptable that anyone should feel harassed or intimidated simply for exercising their legal right to healthcare advice and treatment.\r\n\"The decision to have an abortion is already an incredibly personal one, without women being further pressured by aggressive protesters.\"\r\nShe said the review would provide \"firm recommendations\" on action to tackle the problem.\r\nAmber RuddImage copyrightPA\r\nImage caption\r\nAmber Rudd said it was \"unacceptable\" that anyone should feel intimidated for accessing healthcare\r\nThe police already have a range of powers to manage protests, with the law providing protection against harassment and intimidation.\r\nThe Home Office said protesters were subject to the law and all suspected offences \"will be robustly investigated\".\r\nMs Huq said she welcomed the review with \"cautious optimism\".\r\nShe said a radial zone to exclude protests within 150m was needed, banning silent praying, singing hymns, displaying foetus images and leaflet distribution.\r\n\"The complete anonymity of women seeking terminations should be protected as one would expect with any other NHS procedure,\" she said.\r\nPolicing minister Nick Hurd has written to the national policing lead for protest, Deputy Chief Constable Rachel Swann to begin the work.\r\nThe review will be conducted by Home Office officials and will also consider international comparisons in Australia, France and the US.', '2017-11-26 09:09:20', '2017-11-26 09:09:20'),
(12, 'Oxford Circus panic: Pair released after police questioning', 'Two men questioned over an altercation that sparked panic in London\'s Oxford Street on Friday have been released without charge, police have said.\r\nThe pair - aged 21 and 40 - were quizzed on Saturday after attending a police station voluntarily.\r\nBritish Transport Police are investigating after panic erupted inside Oxford Circus Tube station.\r\nSeveral people were injured and nine taken to hospital as people fled the station amid reports shots were fired.\r\nArmed police were sent to the scene amid fears it could have been a terrorist attack.\r\nHowever, officers said they had found no evidence any gunshots had been fired.\r\nPolice later said the incident may have been caused by an altercation between two men on a station platform.\r\nThey released CCTV images of two men they wanted to speak to in connection with the incident.\r\nConfirming the men had been released, a spokeswoman for British Transport Police said: \"There are no criminal proceedings against them.\r\n\"They have not been arrested or charged.\"', '2017-11-26 09:09:42', '2017-11-26 09:09:42'),
(13, 'UK drone users to sit safety tests under new law', 'Drone users in the UK may have to take safety awareness tests under legislation planned by the government.\r\nDrones weighing more than 250g could also be banned from flying near airports, or above 400 ft, in a crackdown on unsafe flying.\r\nPolice will also be given new powers to seize and ground drones which may have been used in criminal activity.\r\nThe bill has been welcomed by the pilots\' union, which has warned of near misses involving drones and aircraft.\r\nBalpa said there had been 81 incidents so far this year - up from 71 in 2016 and 29 in 2015.\r\nThe union\'s general secretary, Brian Strutton, said: \"These proposals are a step towards the safe integration of drones, but until the new rules are in place the threat of a serious collision remains.\"\r\nIn July a drone flew directly over the wing of a large passenger jet as it came into land at London\'s Gatwick Airport, which a report said had put 130 lives at risk.\r\nDrones scatter mosquitoes to fight diseases\r\nThe flying drones that can scan packages night and day\r\nDrone detects heartbeat and breathing rates\r\nThe proposed bill - to be published in spring 2018 - would ensure that owners of drones weighing more than 250g would need to register and sit a test.\r\nDrone pilot and trainer Elliott Corke, director of HexCam, said most recreationally and commercially-used drones in use weighed more than 250g, apart from the cheap toy versions.\r\nHe told BBC News that many new users were surprised by how many rules around drone usage already exist, under the Civil Aviation Authority\'s Drone Code.\r\nHe said there was a \"degree of frustration\" however that the rules were not being enforced effectively, allowing criminal activity to take place.\r\n\r\n\r\nMedia captionWatch a drone deliver drugs and mobile phones to London prisoners\r\nSerena Kennedy, Assistant Chief Constable of the National Police Chiefs Council (NPCC), told BBC Breakfast: \"At the moment we\'re using other bits of legislation - the Civil Aviation Authority\'s - to enable us to take action.\r\n\"This draft legislation will give us the powers we need to tackle drones when they are being used for criminal purposes.\"\r\nShe said it would help police tackle the \"increasing problem\" of drones delivering items, such as drugs and mobile phones, to prisons.\r\nShe said the legislation could allow police to look at how they can protect prison establishments from criminal drone activity through geo-fencing, which programmes no-fly zones into drones using GPS co-ordinates.\r\n\r\n\r\nMedia captionDrones should be flown no higher than 400ft\r\nChristian Struwe, head of European public policy at drone maker DJI, warned that some of the proposals may be \"difficult to police\" - for example the height restriction.\r\nBut he told BBC Breakfast: \"The good thing is that as an industry we are already working on it. We can limit how high they can fly.\"\r\nMr Struwe pointed out that there was no \"hard limit\" on how close drones could fly to airports. \"The current wording is that you should stay well clear,\" he said.\r\nHe welcomed the proposals to limit the \"bad use\" of drones, adding that it was important people were aware there was regulation they needed to follow.\r\nMr Corke agreed that there was a \"lack of awareness\" of the Drone Code, and said he was frustrated by the lack of focus on practical training.\r\n\"Most people don\'t read the manual or learn the safety features before they use their drones\", he said, adding that many did not know what to do if something malfunctioned.\r\nDrone deliveries\r\nAlongside the new laws, the government is also keen to develop technology allowing the greater use of drones for tasks including deliveries of everything from shopping to human organs.\r\nThe transport minster, Lady Sugg, said the government wanted to strike the right balance between harnessing drone potential and ensuring they are not misused.\r\n\"We\'re bringing forward this legislation in order to ensure that drones can be used safely, whilst also addressing some of the safety and privacy concerns that people have,\" she said.\r\nThe government is also working with drone manufacturers on technology which produces virtual barriers, to stop the machines operating in restricted areas.', '2017-11-26 09:10:08', '2017-11-26 09:10:08'),
(14, 'Just Eat set to join blue chip index after share price jump', 'An online takeaway firm is set to join the ranks of Britain\'s biggest businesses this week.\r\nJust Eat is expected to be promoted to the FTSE 100 on the back of its soaring share price, and comes just three years after its stock market debut.\r\nIts elevation would make it the first such firm to join the blue chip index.\r\nThe next FTSE reshuffle is based on closing share prices on Tuesday, with engineer Babcock and Alton Towers-owner Merlin at risk of demotion.\r\nJust Eat\'s shares have soared 43% this year on the back of revenue growth and acquisitions. It\'s £5.5bn market value makes it bigger than Sainsbury\'s.\r\nJust Eat takes online orders from customers and acts as delivery middle man between them and restaurants.\r\nNicholas Hyett, equity analyst at Hargreaves Lansdown, said Just Eat\'s growth underlines changing consumer habits and the impact of consumer-facing tech firms.\r\n\"Reshuffles in and out of the FTSE 100 are somewhat symbolic but can highlight companies whose stars are in the ascendancy, Just Eat being a good example - having only floated a little over three years ago,\" he said.\r\n\"Customers are fast-adopting online ordering as their default order route, and Just Eat has been growing orders and revenues at a rate of knots.\"\r\nEarlier this month, the Competition and Markets Authority cleared Just Eat\'s £240m takeover of rival Hungryhouse.\r\nDemotion\r\nBabcock, one of the UK\'s oldest engineering firms, has seen its share price hit on concerns about defence spending, and is one of the companies most likely to be demoted to the FTSE 250.\r\nMerlin, which also owns Madame Tussauds and the London Eye, has seen visitor numbers tail off in response to the heightened UK threat level, with the blame also being pinned on poor late summer weather across the UK and northern Europe.\r\nThe third company tipped for FTSE 100 ejection is hospital group Mediclinic International, which recently ended takeover talks with Spire Healthcare.\r\nIn addition to Just Eat\'s promotion, Mr Hyett says paper packaging business DS Smith and Halma, a health and safety technology company, are on course to join the FTSE 100.\r\nChanges to the FTSE 100 and 250 will take effect in mid-December.', '2017-11-26 09:10:25', '2017-11-26 09:10:25'),
(15, 'Liverpool police officer hit by van in Norris Green', 'A police officer has been seriously injured when he was hit by a van driven at him in Liverpool.\r\nPolice were trying to stop a white Transit van in Norris Green when it was driven onto the pavement and then at the officer at 19:25 GMT on Saturday.\r\nThe officer was taken to hospital following the \"despicable attack\" where he is being treated for injuries to his ribs and leg, Merseyside Police said.\r\nA man, from Everton, has been arrested on suspicion of attempted murder.\r\nThe 34-year-old, who is also being held on possession of cannabis and driving while under the influence of drink or drugs, remains in custody.\r\nThe van hit a police car and other parked vehicles on Hasfield Road before it was driven at the officer, detectives said.\r\nroad\r\nImage caption\r\nThe policeman\'s injuries are not thought to be life-threatening\r\nDet Ch Insp Martin Earl said: \"This was a despicable attack on a police officer who was simply doing his job, trying to protect the communities of Merseyside.\r\n\"The officer has sustained serious injuries for which he is receiving treatment. He has also been left extremely shaken by his ordeal.\"\r\n\'Dangers of policing\'\r\nHe added that colleagues have been left \"shocked\" by the incident and are being provided with support.\r\nPeter Singleton, chair of the Merseyside branch of the Police Federation - which represents 120,000 officers across the UK - said it was \"another sobering reminder of how dangerous policing can be\".\r\n\"It\'s an incident that shows there are individuals out there who really just do not care, have no thoughts for other people - for the public or police officers - and their safety,\" he said.\r\nHe added it was an \"unnerving reminder\" of the death of Merseyside Police officer Dave Phillips, who was killed while trying to stop a stolen vehicle in 2015.', '2017-11-26 09:10:48', '2017-11-26 09:10:48');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'web', '2017-11-26 06:56:27', '2017-11-26 06:56:27'),
(2, 'Owner', 'web', '2017-11-26 06:56:55', '2017-11-26 06:56:55'),
(3, 'Editor', 'web', '2017-11-26 06:57:26', '2017-11-26 06:57:26'),
(4, 'Member', 'web', '2017-11-26 07:02:38', '2017-11-26 07:02:38');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(2, 1),
(2, 2),
(2, 3),
(3, 1),
(3, 2),
(4, 1),
(5, 1),
(5, 2),
(5, 3),
(5, 4);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `birthday` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`, `birthday`) VALUES
(1, 'Pham Cong', 'vcong.pham@gmail.com', '$2y$10$68SYQo1WsCCZbPCkSk3vnuz7/bItUnUTw7qrh8MyaCbHQB3rFAZua', 'oZRQxz9muFhYXoJjni221vyReIxQCUTstbPAbQwwjZDtEchQPA2nHxdbTRQq', '2017-11-26 06:51:15', '2017-11-26 06:58:10', ''),
(2, 'Owner User', 'owner@gmail.com', '$2y$10$So.WfSckGFVWgs99fqRzruIousDQgAkdnDAAthPDDgAt9LCNZd1eG', 'n4voxYQG7d90RRrQE8sFuvMTNq7VuOBjsSWZew0Mu92ikV0smuzSRzQdn1Ja', '2017-11-26 07:00:14', '2017-11-26 07:00:14', ''),
(3, 'Editor User', 'editor@gmail.com', '$2y$10$2OG2EjQqpwWuNeD3sMxJ2O9mYSCal..lRfmMGfHYvoyzjhFZUIH72', 'HQXNkCmWvEueNFuVjJJONFUKlMx4QuSkbBQljaumXdCqdqzvCW0ixZQjjTXZ', '2017-11-26 07:00:45', '2017-11-26 07:00:45', ''),
(4, 'User 1', 'user1@gmail.com', '$2y$10$v7fn.xSUZAnxnFe97htW9utyeh0iuP1aNg/e1k7XK.EStoXMnPzFq', 'DBhVFDw6aYTJsVUS135BhjsqABpsqsfXwIKjraaFo1wJvzaV3sI4eyYSbA4U', '2017-11-26 07:03:59', '2017-11-26 07:03:59', ''),
(5, 'User 2', 'user2@gmail.com', '$2y$10$dLzKVZOfeW4lYUXR25CA9.Wj8TjPycbVly..7QvE9aqN.19zlDGV.', NULL, '2017-11-26 07:04:22', '2017-11-26 07:04:22', ''),
(6, 'test user', 'test1@gmail.com', '$2y$10$8OCCHXi7EA.Z1atVrLSU.ucOE1aO4qBTuaiKvdo90yuk0EAXtnJ5i', 'ISHmlETttKFouaJJcUg9yLN2r6ACeZP3VY1M4EgW3O6bnvNIkOSePan3cLoc', '2017-11-26 07:40:31', '2017-11-26 07:40:31', ''),
(7, 'test user 2', 'test2@gmail.com', '$2y$10$o2EaPx42QclfvEy7bVdOg.rgGI0lzU33wXN51eq82cpcq/BJ1walC', NULL, '2017-11-26 07:43:54', '2017-11-26 07:43:54', ''),
(8, 'test user 3', 'test3@gmail.com', '$2y$10$2fLTj8WbxBEnpvkRFCqZoOR0.uG6uBwbrE/LpnbfFZHV9c1/D6eV.', 'I0sm38IFozeUb2f3uKPBFL7FnxN4OO8hp11JbGwiVFLru0ob0k4dDLRMpFiY', '2017-11-26 07:44:43', '2017-11-26 07:44:43', ''),
(9, 'test user 4', 'test4@gmail.com', '$2y$10$w2dyhY94lymhkajPKr2Zu..Stgv9xOXf.6bAnJMUeVZ/vPZFiShIO', 'LM5aldGu8LuC4eiKWJGm8upzpWU5BfCNKUbJKghJppzXME1wOqhqeQJ0DrbU', '2017-11-26 08:00:23', '2017-11-26 08:00:23', '15/11/2017'),
(10, 'test new', 'test5@gmail.com', '$2y$10$maFAZXzCNeIgOPxA8.UZ8ukQzQQbPgySX6KHAkJBdISKuj3xbtJe6', 'i2jKL2uwUqhRAtml2EsmNxm2fEKVPR4qnTYYFkV43TTOCiHM5eRh3lAuKSDC', '2017-11-26 10:37:17', '2017-11-26 10:37:17', '01/11/2017');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
